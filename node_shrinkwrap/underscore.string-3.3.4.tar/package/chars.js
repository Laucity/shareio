var makeString = require('./helper/makeString');

module.exports = function chars(str) {
  return makeString(str).split('');
};
