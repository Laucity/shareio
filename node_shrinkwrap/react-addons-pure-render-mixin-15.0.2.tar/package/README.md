# react-addons-pure-render-mixin

This package provides the React PureRenderMixin add-on.

See <https://facebook.github.io/react/docs/pure-render-mixin.html> for more information.