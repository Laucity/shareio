### Version
Tell us which versions you are using: 

- react-native-router-flux v3.?.?
- react-native v0.?.?

### Expected behaviour



### Actual behaviour



### Steps to reproduce

1.
2.
3.


