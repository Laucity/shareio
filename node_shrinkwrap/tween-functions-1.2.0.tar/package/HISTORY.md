Legend:

- [B]: Breaking
- [F]: Fix
- [I]: Improvement

### 1.2.0 (November 20th 2015)
- [F] Fix return value of `easeInOutExpo`, `easeInElastic`, `easeOutElastic` and `easeInOutElastic`. 20b7790

### 1.1.0 (October 16th 2015)
- [F] Fix `easeInExpo` and `easeOutExpo`. #2

### 1.0.2 (May 25th 2015)
- Initial release.
