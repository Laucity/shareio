var foo = require('./foo.js');
var bar = require('./bar.js');

console.log(foo.ooo(bar(2)));
