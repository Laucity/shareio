//
//  TickView.h
//  RCTMaterialKit
//
//  Created by Yingxin Wu on 15/12/20.
//  Copyright © 2015年 https://github.com/xinthink. All rights reserved.
//

#ifndef TickView_h
#define TickView_h

@import UIKit;

@interface TickView : UIControl

@property float inset;  // Insets of the tick

@end

#endif /* TickView_h */
