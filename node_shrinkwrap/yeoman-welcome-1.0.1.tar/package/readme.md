# yeoman-welcome [![Build Status](https://travis-ci.org/yeoman/yeoman-welcome.svg?branch=master)](https://travis-ci.org/yeoman/yeoman-welcome)

> Yeoman welcome message used in generators

![](screenshot.png)


## Install

```sh
$ npm install --save yeoman-welcome
```


## Usage

```js
console.log(require('yeoman-welcome'));
```


## License

MIT © Yeoman
