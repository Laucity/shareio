#import "RTSpinKitView.h"

@interface RNSpinkit : UIView

@end