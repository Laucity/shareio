#ifndef RNSpinkit_RCTViewManager_h
#define RNSpinkit_RCTViewManager_h

#import "RCTViewManager.h"

@interface RNSpinkitManager : RCTViewManager

@end


#endif