//
//  RNVectorIconsManager.h
//  RNVectorIconsManager
//
//  Created by Joel Arvidsson on 2015-05-29.
//  Copyright (c) 2015 Joel Arvidsson. All rights reserved.
//

#import "RCTBridgeModule.h"
#import "RCTLog.h"

@interface RNVectorIconsManager : NSObject <RCTBridgeModule>

@end
